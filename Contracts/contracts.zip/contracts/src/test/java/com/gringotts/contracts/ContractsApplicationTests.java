package com.gringotts.contracts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContractsApplicationTests {

	@Test
	void contextLoads() {
	}

}
